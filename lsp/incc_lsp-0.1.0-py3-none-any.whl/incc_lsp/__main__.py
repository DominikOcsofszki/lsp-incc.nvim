from incc_lsp.lsp_server import LSP_SERVER

LSP_SERVER.run()
