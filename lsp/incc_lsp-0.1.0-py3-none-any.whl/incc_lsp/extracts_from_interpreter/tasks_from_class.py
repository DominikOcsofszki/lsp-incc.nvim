keywords = {
    "tasks0": "Zum warm werden: Lexer für Algol60 (Verpflichtend)",
    "tasks1": "Arithmetische und Boole'sche Ausdrücke (Verpflichtend)",
    "tasks2": "Variablen und Sequenzierung (Verpflichtend)",
    "tasks3": "If-Then-Else, Loop und For-Schleife (Verpflichtend)",
    "tasks4": "While-Schleife und Locale Scopes (Verpflichtend)",
    "tasks5": "Lambda-Ausdücke und rekursives local-Statement (Verpflichtend)",
    "tasks6": "n-stellige Funktionen und elementare Datentypen (Verpflichtend)",
    "tasks7": "Beutzerdefinierte Strukturen (Verpflichtend)",
}
