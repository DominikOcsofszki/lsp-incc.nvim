from incc_lsp.lsp_server import LSP_SERVER


def run_lsp_server():
    LSP_SERVER.run()
