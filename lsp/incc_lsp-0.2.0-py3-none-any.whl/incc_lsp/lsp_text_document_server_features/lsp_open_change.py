from lsprotocol import types

from incc_lsp.lsp_extract_text_document import extract_lsp_diagnostic
from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer
from incc_lsp.lsp_server.lsp_server_logging import LOGGING


def create_did_open(SERVER: InCCLanguageServer):
    @SERVER.feature(types.TEXT_DOCUMENT_DID_OPEN)
    def did_open(ls: InCCLanguageServer, params: types.DidOpenTextDocumentParams):
        """Parse each document when it is changed, did_open"""
        LOGGING.debug("""Parse each document when it is changed, did_open""")
        document = SERVER.workspace.get_text_document(params.text_document.uri)
        extract_lsp_diagnostic.parse_and_check_for_errors(ls, document)


def create_did_change(SERVER: InCCLanguageServer):
    @SERVER.feature(types.TEXT_DOCUMENT_DID_CHANGE)
    def did_change(ls: InCCLanguageServer, params: types.DidOpenTextDocumentParams):
        """Parse each document when it is changed"""
        document = SERVER.workspace.get_text_document(params.text_document.uri)
        LOGGING.debug("""Parse each document when it is changed, did_change""")
        extract_lsp_diagnostic.parse_and_check_for_errors(ls, document)
