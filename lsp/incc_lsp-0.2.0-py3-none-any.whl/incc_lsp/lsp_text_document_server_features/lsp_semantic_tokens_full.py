from lsprotocol import types

from incc_lsp.lsp_extract_text_document import extract_lsp_semantic_tokens_full
from incc_lsp.lsp_extract_text_document.TokenInfoClasses import InccSemanticToken
from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer

# TODO: Compare speed inside func or outside
lexer_reserved_words_dict = InCCLanguageServer.lexer_reserved_words_dict.keys()
InCCLanguageServer_token_types = InCCLanguageServer.token_types
InCCLanguageServer_token_types_dict = InCCLanguageServer.token_types_dict


def get_TokenTypes(token: InccSemanticToken):
    if token.tok_type == "IDENT" and token.text in lexer_reserved_words_dict:
        highlight_type = "keyword"
    else:
        highlight_type = InCCLanguageServer_token_types_dict.get(
            token.tok_type, "namespace"
        )
    ret_index = InCCLanguageServer_token_types.index(highlight_type)
    return ret_index


def extract_sem_tok_info(tokens: list[InccSemanticToken]):
    data = [
        item
        for token in tokens
        for item in [
            token.line_offset,
            token.pos_offset,
            len(token.text),
            get_TokenTypes(token),
            0,
        ]
    ]
    return data


def create(SERVER: InCCLanguageServer):
    @SERVER.feature(
        types.TEXT_DOCUMENT_SEMANTIC_TOKENS_FULL,
        types.SemanticTokensLegend(
            token_types=InCCLanguageServer.token_types,
            token_modifiers=InCCLanguageServer.token_modifiers,
        ),
    )
    def semantic_tokens_full(
        incc_server: InCCLanguageServer,
        params: types.SemanticTokensParams,
    ):
        """Return the semantic tokens for the entire document"""
        document = incc_server.workspace.get_text_document(params.text_document.uri)
        tokens: list[InccSemanticToken] = (
            extract_lsp_semantic_tokens_full.parseHighlightTokens(document.source)
        )
        data = extract_sem_tok_info(tokens)
        semanticTokens = types.SemanticTokens(data=data)
        return semanticTokens
