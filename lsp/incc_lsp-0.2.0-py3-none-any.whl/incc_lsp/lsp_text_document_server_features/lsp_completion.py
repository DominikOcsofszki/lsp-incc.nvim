from lsprotocol import types

from incc_lsp.extracts_from_interpreter import PARSER_LSP
from incc_lsp.extracts_from_interpreter.interpreter_class_info import III
from incc_lsp.lsp_extract_text_document import extract_lsp_completion
from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer
from incc_lsp.lsp_server.lsp_server_logging import LOGGING

# __RESERVED_WORDS = [str.lower(x) for x in III.LEXER_reserved_words]
# RESERVED_WORDS = [types.CompletionItem(label=x, kind=14) for x in __RESERVED_WORDS]

__RESERVED_WORDS = [
    str.lower(reserved_word) for reserved_word in III.LEXER_reserved_words
]
__RESERVED_WORDS_IMPORT = [
    keyword for keyword in III.LEXER_reserved_keywords_from_import
]
_RESERVED_WORDS_IMPORT = [
    types.CompletionItem(label=x, kind=24) for x in __RESERVED_WORDS_IMPORT
]
_RESERVED_WORDS = [types.CompletionItem(label=x, kind=14) for x in __RESERVED_WORDS]

RESERVED_WORDS_AND_IMPORTS = _RESERVED_WORDS + _RESERVED_WORDS_IMPORT

# @enum.unique
# class CompletionItemKind(int, enum.Enum):
#     """The kind of a completion entry."""
#
#     Text = 1
#     Method = 2
#     Function = 3
#     Constructor = 4
#     Field = 5
#     Variable = 6
#     Class = 7
#     Interface = 8
#     Module = 9
#     Property = 10
#     Unit = 11
#     Value = 12
#     Enum = 13
#     Keyword = 14
#     Snippet = 15
#     Color = 16
#     File = 17
#     Reference = 18
#     Folder = 19
#     EnumMember = 20
#     Constant = 21
#     Struct = 22
#     Event = 23
#     Operator = 24
#     TypeParameter = 25


def filter_comp_items(all_comp_items: list[types.CompletionItem], word):
    # TODO: Filter by letters, but usually done in front-end, caching
    # all_comp_items.sort(key=lambda x: x.label[0])
    filtered_items = [
        x for x in all_comp_items if x.label and word and x.label[0] == word[0]
    ]
    filtered_items.sort(key=lambda x: x.label[0])
    return filtered_items


def check_for_struct_dots_parent(current_line_up_to_char):
    max = len(current_line_up_to_char)
    dots = 1
    for i in range(1, max):
        if not current_line_up_to_char[-i] == ".":
            return dots
        dots = i

    return dots


def check_if_inside_struct_def():
    return False


def check_if_dots_as_trigger(document, params):
    current_line_up_to_char = document.lines[params.position.line][
        : params.position.character
    ]
    if params.context and (
        params.context.trigger_character == "."
        or (current_line_up_to_char and current_line_up_to_char[-1] == ".")
        or (
            current_line_up_to_char
            and len(current_line_up_to_char) > 2
            and current_line_up_to_char[-2] == "."
        )
    ):
        LOGGING.warn(f"current_line_up_to_char:{current_line_up_to_char}")
        return check_for_struct_dots_parent(current_line_up_to_char)
    else:
        return None


def return_extends_completions(document, params, word):
    LOGGING.warning("========================")
    LOGGING.warning("========================")
    LOGGING.warning(f"word: {word}")
    struct_extends_entries_keys = [
        x for x in PARSER_LSP.get_struct_extends().get_keys()
    ]
    LOGGING.warning(f"struct_extends_entries_keys: {struct_extends_entries_keys}")
    ids_might_be_structs_lsp_structs = PARSER_LSP.get_ids_might_be_structs_lsp_structs()
    LOGGING.warning(
        f"ids_might_be_structs_lsp_structs: {ids_might_be_structs_lsp_structs}"
    )
    # ids_might_be_structs_lsp_structs = PARSER_LSP.get_ids_might_be_structs_lsp_structs()
    # LOGGING.warning(
    #     f"ids_might_be_structs_lsp_structs: {ids_might_be_structs_lsp_structs}"
    # )
    LOGGING.warning("========================")
    LOGGING.warning("========================")
    # if word not in struct_extends_entries_keys:
    LOGGING.warning(f"{ids_might_be_structs_lsp_structs}")
    if word not in ids_might_be_structs_lsp_structs:
        return

    return types.CompletionList(
        items=[
            types.CompletionItem(
                label=x,
                label_details=types.CompletionItemLabelDetails(
                    # f"{entries[x].lineno}" if entries[x] else None
                    f"_ extended by {x} between line: {[(x.lineno[0] + 1, x.lineno[1] + 1) for x in ids_might_be_structs_lsp_structs[x]]}"
                    if ids_might_be_structs_lsp_structs[x]
                    else None
                ),
                kind=22,
            )
            # for x in struct_extends.get_keys()
            for x in struct_extends_entries_keys
        ],
        is_incomplete=False,
    )


# def get_correct_extend_struct(document, params, dots, lsp_struct, word):
#     LOGGING.warning(f"lsp_struct:{lsp_struct}")
#     LOGGING.warning(f"lsp_struct.get_keys():{lsp_struct.get_keys()}")
#     ids_might_be_structs_lsp_structs = PARSER_LSP.get_ids_might_be_structs_lsp_structs()
#     LOGGING.warning(
#         f"ids_might_be_structs_lsp_structs:{ids_might_be_structs_lsp_structs}"
#     )
#     if word in ids_might_be_structs_lsp_structs:
#         word_info_inside_struct = ids_might_be_structs_lsp_structs[word]
#         LOGGING.warning(f"word:{word},word_info_inside_struct{word_info_inside_struct}")
#         lexpos_check_if_inside = word_info_inside_struct[0].lexpos
#         all_struct_entries = lsp_struct.get_entries()
#         LOGGING.warning(f"lexpos_check_if_inside:{lexpos_check_if_inside}")
#         LOGGING.warning(f"all_struct_entries:{all_struct_entries}")
#         arr_ret = []
#         for struct_var, struct_value in all_struct_entries.items():
#             LOGGING.warning(f"struct_var:{struct_var}: struct_value:{struct_value}")
#             for entry in struct_value:
#                 if (
#                     lexpos_check_if_inside[0] >= entry.lexpos
#                     and entry.lexpos <= lexpos_check_if_inside[1]
#                 ):
#                     LOGGING.warning(f"HAAAAA")
#                     # arr_ret.append(entry)
#                     arr_ret.append(struct_var)
#         LOGGING.warn(f"arr_ret:{arr_ret}")


def get_correct_extend_struct(document, params, dots, lsp_struct, word):
    ids_might_be_structs_lsp_structs = PARSER_LSP.get_ids_might_be_structs_lsp_structs()
    if word in ids_might_be_structs_lsp_structs:
        word_info_inside_struct = ids_might_be_structs_lsp_structs[word]
        lexpos_check_if_inside = word_info_inside_struct[0].lexpos
        all_struct_entries = lsp_struct.get_entries()
        arr_ret = []
        for struct_var, struct_value in all_struct_entries.items():
            for entry in struct_value:
                if (
                    lexpos_check_if_inside[0] >= entry.lexpos
                    and entry.lexpos <= lexpos_check_if_inside[1]
                ):
                    arr_ret.append(struct_var)
        LOGGING.warn(f"arr_ret:{arr_ret}")


def return_struct_extend_completions(document, params, dots, lsp_struct):
    params.position.character -= dots
    word = document.word_at_position(params.position)
    inside_struct_def = check_if_inside_struct_def()
    if not word and not inside_struct_def:
        return
    if dots == 1:
        arr = get_correct_extend_struct(document, params, dots, lsp_struct, word)

        return types.CompletionList(
            items=[
                types.CompletionItem(label=x, kind=22) for x in lsp_struct.get_keys()
            ],
            is_incomplete=False,
        )
    elif dots == 2:
        return return_extends_completions(document, params, word)
    else:
        return


# def filter_entries_lines_TODO(lsp_dict, from_line, to_line):
#     lsp_dict_entries = lsp_dict.entries
#
#     filtered_data = {
#         key: [
#             entry
#             for entry in value
#             if from_line >= entry.lineno and entry.lineno <= to_line
#         ]
#         for key, value in lsp_dict_entries.items()
#         if any(from_line >= entry.lineno and entry.lineno <= to_line for entry in value)
#     }
#     return filtered_data


def filter_entries_lines(lsp_dict, from_line, to_line):
    lsp_dict_entries = lsp_dict.entries

    filtered_data = {
        key: [entry for entry in value if entry.lineno < to_line]
        for key, value in lsp_dict_entries.items()
        if any(entry.lineno < to_line for entry in value)
    }
    return filtered_data


def return_id_and_keywords_completions(document, params, USE_FILTER):
    lsp_def = PARSER_LSP.get_lsp_def()
    ids_might_be_structs_lsp_structs = PARSER_LSP.get_ids_might_be_structs_lsp_structs()
    LOGGING.info(ids_might_be_structs_lsp_structs["stru1"])
    filtered_data = filter_entries_lines(
        lsp_def, from_line=0, to_line=params.position.line
    )
    lsp_def_keys = filtered_data.keys()
    completion_ids = [types.CompletionItem(label=x, kind=6) for x in lsp_def_keys]
    all_items = RESERVED_WORDS_AND_IMPORTS + completion_ids

    if USE_FILTER:
        word = document.word_at_position(params.position)
        if word:
            all_items = filter_comp_items(all_items, word)

    return types.CompletionList(items=all_items, is_incomplete=False)


def create(SERVER: InCCLanguageServer):
    # TODO: usually done in front-end, caching
    USE_FILTER = SERVER.CONF_COMPLETION_USE_FILTER

    @SERVER.feature(
        types.TEXT_DOCUMENT_COMPLETION,
        types.CompletionOptions(trigger_characters=["."]),
    )
    def completions(params: types.CompletionParams):
        document = SERVER.workspace.get_text_document(params.text_document.uri)
        dots = check_if_dots_as_trigger(document, params)
        if dots:
            lsp_struct = PARSER_LSP.get_struct_vars()
            return return_struct_extend_completions(document, params, dots, lsp_struct)
        else:
            return return_id_and_keywords_completions(document, params, USE_FILTER)
            # lsp_def_keys = PARSER_LSP.get_lsp_def().get_keys()
            # completion_ids = [
            #     types.CompletionItem(label=x, kind=6) for x in lsp_def_keys
            # ]
            # all_items = RESERVED_WORDS + completion_ids
            #
            # if USE_FILTER:
            #     word = document.word_at_position(params.position)
            #     if word:
            #         all_items = filter_comp_items(all_items, word)
            #
            # return types.CompletionList(items=all_items, is_incomplete=False)


if __name__ == "__main__":

    def add_helper_reserved_word():
        arr = [str.lower(x) for x in III.LEXER_reserved_words]
        return [types.CompletionItem(label=x, kind=6) for x in arr]

    res = add_helper_reserved_word()
    filt = filter_comp_items(res, "word")
    for x in filt:
        print(x.label)
