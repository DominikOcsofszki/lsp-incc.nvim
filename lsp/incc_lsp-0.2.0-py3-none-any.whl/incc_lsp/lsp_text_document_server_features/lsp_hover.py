from lsprotocol import types

from incc_lsp.extracts_from_interpreter import LEXER_TOKS
from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer
from incc_lsp.lsp_server.lsp_server_logging import LOGGING
from incc_lsp.lsp_text_import_hover import HOVER_ALL

comments_json_hover = HOVER_ALL.get_all_tasks_json_hover()
comments_json_hover_keys = comments_json_hover.keys()


def create(SERVER: InCCLanguageServer):
    @SERVER.feature(types.TEXT_DOCUMENT_HOVER)
    def completions(params: types.CompletionParams):
        document = SERVER.workspace.get_text_document(params.text_document.uri)
        current_line = document.lines[params.position.line]
        tok_hover = LEXER_TOKS.from_line_match_get_id(
            current_line, params.position.character
        )

        if tok_hover:
            tok_hover_lower = str.lower(tok_hover)
            hover_content = ""
            if not tok_hover.startswith("#"):
                hover_content: str = HOVER_ALL.hover_dict_lower_case.get(
                    f"{tok_hover_lower}", ""
                )
                if not hover_content:
                    return
            else:
                tok_hover = document.word_at_position(params.position)
                for key in comments_json_hover_keys:
                    if key in tok_hover:

                        LOGGING.info(tok_hover)
                        hover_content: str = comments_json_hover.get(
                            f"{str.lower(key)}", ""
                        )

                        break

            hover_content = f"# {tok_hover}  \n - {hover_content}"

            return types.Hover(
                contents=types.MarkupContent(
                    kind=types.MarkupKind.Markdown, value=hover_content
                )
            )
