from lsprotocol import types

from incc_lsp.extracts_from_interpreter import LEXER_TOKS, PARSER_LSP
from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer
from incc_lsp.lsp_server.lsp_server_logging import LOGGING


def find_column(input, lexpos):
    line_start = input.rfind("\n", 0, lexpos) + 1
    return lexpos - line_start


def helper_create_range_items(tok):
    char_pos: int = 0
    line_nr: int = tok.lineno - 1
    range_ = types.Range(
        start=types.Position(line=line_nr, character=char_pos),
        end=types.Position(line=line_nr, character=char_pos),
    )
    return range_


def filter_before_lexpos(arr, params):
    return list(filter(lambda id: id.lineno <= params.position.line, arr))


def filter_lsp_def(params, document, id_under_courser_defined_at):
    filtered = filter_before_lexpos(id_under_courser_defined_at, params)
    if filtered:
        current_id = filtered[-1]
        lexpos = current_id.lexpos
        column = find_column(document.source, lexpos)
        return [
            types.Location(
                uri=document.uri,
                range=types.Range(
                    start=types.Position(line=current_id.lineno, character=column),
                    end=types.Position(line=current_id.lineno, character=column),
                ),
            )
        ]


def create(SERVER: InCCLanguageServer):
    @SERVER.feature(types.TEXT_DOCUMENT_DEFINITION)
    def goto_definition(ls: InCCLanguageServer, params: types.DefinitionParams):
        document = SERVER.workspace.get_text_document(params.text_document.uri)
        current_line = document.lines[params.position.line]
        tok_under_courser = LEXER_TOKS.from_line_match_get_id(
            current_line, params.position.character
        )
        lsp_defs, lsp_refs, lsp_structs = PARSER_LSP.get_def_ref_struct_lsp()
        id_under_courser_defined_at = lsp_defs.entries.get(tok_under_courser)
        LOGGING.info(id_under_courser_defined_at)
        if id_under_courser_defined_at:
            return filter_lsp_def(params, document, id_under_courser_defined_at)
