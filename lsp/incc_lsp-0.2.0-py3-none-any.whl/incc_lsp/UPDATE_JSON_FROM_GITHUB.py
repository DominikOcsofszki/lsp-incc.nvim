from incc_lsp.lsp_text_import_hover import load_from_github


def update_hover_from_github():
    load_from_github.update_all_hover(True)


if __name__ == "__main__":
    update_hover_from_github()
