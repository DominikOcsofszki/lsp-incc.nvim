from incc_lsp.lsp_server.lsp_pre_server import InCCLanguageServer
from incc_lsp.lsp_text_document_server_features import (  # lsp_diagnostic,
    lsp_completion,
    lsp_definition,
    lsp_hover,
    lsp_open_change,
    lsp_reference,
    lsp_rename,
    lsp_semantic_tokens_full,
)

EXPERIMENTAL = False


def run():
    INCC_SERVER = InCCLanguageServer("incc-server", "v0.1")
    lsp_completion.create(INCC_SERVER)
    lsp_definition.create(INCC_SERVER)
    lsp_reference.create(INCC_SERVER)
    lsp_hover.create(INCC_SERVER)
    lsp_semantic_tokens_full.create(INCC_SERVER)
    lsp_open_change.create_did_change(INCC_SERVER)
    lsp_open_change.create_did_open(INCC_SERVER)
    if EXPERIMENTAL:
        lsp_rename.create(INCC_SERVER)
    INCC_SERVER.start_io()


#
# def run_vs_code():
#     INCC_SERVER = InCCLanguageServer("incc-server", "v0.1")
#     create_lsp_text_document_completion(SERVER=INCC_SERVER)
#     create_lsp_text_document_hover(SERVER=INCC_SERVER)
#     create_go_to_def(SERVER=INCC_SERVER)
#     # Change to Websocket?
#     INCC_SERVER.start_io()


# run()
# run_vs_code()
