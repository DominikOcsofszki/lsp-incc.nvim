import logging
from pygls.lsp.server import LanguageServer

from incc_lsp.extracts_from_interpreter.interpreter_class_info import (
    III,
)

lexer_reserved_words_dict = {item: "keyword" for item in III.LEXER_reserved_words}
lexer_reserved_words_dict.update(
    {item: "keyword" for item in III.LEXER_reserved_keywords_from_import}
)
__operators_binop: list[str] = [
    "DIVIDE",
    "EQS",
    "GE",
    "GT",
    "LE",
    "LPAREN",
    "LT",
    "MINUS",
    "NEQS",
    "PLUS",
    "TIMES",
    "ASSIGN",
    "RIGHT_ARROW",
    "BACKSLASH",
]
operators_op_dict = {item: "operator" for item in __operators_binop}

literal_tokens: list[str] = [
    "RBRACE",
    "RBRACKET",
    "RPAREN",
    "LBRACE",
    "LBRACKET",
    "COMMA",
    "DOT",
    "SEMICOLON",
]
literal_tokens_dict = {item: "operator" for item in literal_tokens}


class InCCLanguageServer(LanguageServer):
    # CONFIGURATION_SECTION: str = "pygls.incc-server"
    CONF_NAME: str = "pygls.incc-server"
    CONF_COMPLETION_USE_FILTER: bool = True
    # CONF_LOG_LEVEL: int = logging.INFO
    CONF_LOG_LEVEL: int = logging.NOTSET
    # CONF_LOG_LEVEL: int = logging.WARNING
    token_modifiers: list[str] = [
        "declaration",
        "definition",
        "deprecated",
    ]
    token_types: list[str] = [
        "namespace",
        "operator",
        "comment",
        "string",
        "number",
        "struct",
        "parameter",
        "variable",
        "property",
        "keyword",
        "method",
    ]

    token_types_dict: dict[str, str] = {
        "NUMBER": "number",
        "STRING": "string",
        "CHAR": "string",
        # "COMMENT": "comment",
        "COMMENT": "namespace",
        "STRUCT": "struct",
        "IDENT": "variable",
    }
    extra_keywords = ["import", "dict", "["]
    lexer_reserved_words_dict.update({item: "keyword" for item in extra_keywords})

    lexer_reserved_words_dict = lexer_reserved_words_dict
    token_types_dict.update(lexer_reserved_words_dict)
    token_types_dict.update(operators_op_dict)
    token_types_dict.update(literal_tokens_dict)

    def __init__(self, *args):
        super().__init__(*args)

    # def parse_and_check_for_errors(self, ls, document):
    #     parse_and_check_for_errors(ls, document)


if __name__ == "__main__":
    pass
