import re

from incc_interpreter_ue08.lexer.lexer import lexer, lsp_lexer
from ply.lex import Lexer, LexToken

from incc_lsp.lsp_extract_text_document.TokenInfoClasses import (
    InccLexTokenInfo,
    InccSemanticToken,
)
from incc_lsp.lsp_server.lsp_server_logging import LOGGING


def filter_for_items(toks: list[str], pos_nr: int) -> str | None:
    pos_nr = pos_nr + 1
    for x in toks:
        if pos_nr >= x.start() and pos_nr <= x.end():
            return x.group()


def getAllTokens(data: str) -> list[re.Match]:
    lexer = lsp_lexer

    lexer.input(data)
    all_tok: list[any] = []

    while True:
        tok = lexer.token()
        if tok:
            if tok.__dict__.get("lexer"):
                lexmatch = tok.__dict__.get("lexer").__dict__.get("lexmatch")
                all_tok.append(lexmatch)
        if not tok:
            break
    return all_tok


def from_line_match_get_id(line: str, char_pos: int) -> str:
    res = getAllTokens(line)
    item_under_cursor = filter_for_items(res, char_pos)
    return item_under_cursor


# def getAllTokens(data: str) -> list[re.Match]:
#     lexer = lsp_lexer
#
#     lexer.input(data)
#     all_tok: list[any] = []
#
#     while True:
#         tok = lexer.token()
#         if tok:
#             if tok.__dict__.get("lexer"):
#                 lexmatch = tok.__dict__.get("lexer").__dict__.get("lexmatch")
#                 all_tok.append(lexmatch)
#         if not tok:
#             break
#     return all_tok
#
#
# def from_line_match_get_id(line: str, char_pos: int) -> str:
#     res = getAllTokens(line)
#     item_under_cursor = filter_for_items(res, char_pos)
#     return item_under_cursor
#
