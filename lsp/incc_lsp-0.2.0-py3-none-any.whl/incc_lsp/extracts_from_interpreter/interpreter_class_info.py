from incc_interpreter_ue08 import interpreter
from incc_interpreter_ue08.lexer import lexer
from lsprotocol import types as types

from incc_interpreter_ue08.lexer.lexer import lexer, lsp_lexer, reserved_words


class InccInterpreterImported:
    def __init__(self):
        _all_import_keys = [x for x in interpreter.set_up_env().vars.keys()]
        self.LEXER_reserved_keywords_from_import = [
            x for x in _all_import_keys if not str.isupper(x)
        ]
        self.LEXER_reserved_words = reserved_words

    def print_all_infos(self, print_f=print):
        for key in self.__dict__:
            print_f(key, self.__dict__[key])
            print_f()


III = InccInterpreterImported()
