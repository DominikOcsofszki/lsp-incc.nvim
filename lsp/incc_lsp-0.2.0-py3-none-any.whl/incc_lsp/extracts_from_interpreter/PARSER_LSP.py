from incc_interpreter_ue08.lexer import lexer
from incc_interpreter_ue08.LSP import LSP_ENV

# from incc_interpreter_ue08.LSP.LSP_ENV import get_lsp_def, get_lsp_ref
from incc_interpreter_ue08.parser import parser as PARSER


def get_all():
    return LSP_ENV.GET_ALL_LSP_ENV()


def get_struct_vars():
    return LSP_ENV.get_lsp_structs()


def get_lsp_def():
    return LSP_ENV.get_lsp_def()


def get_ids_might_be_structs_lsp_structs():
    return LSP_ENV.get_ids_might_be_structs_lsp_structs()


def get_lsp_structs_create():
    return LSP_ENV.get_lsp_structs_create()


def get_struct_extends():
    return LSP_ENV.get_lsp_structs_extends_create()


def get_struct_infos():
    # PARSER.parse_expr(text)
    struc_ = LSP_ENV.get_lsp_structs()
    print(struc_)
    return struc_


def get_def_ref_struct_lsp():
    return LSP_ENV.get_lsp_def(), LSP_ENV.get_lsp_ref(), LSP_ENV.get_lsp_structs()


def get_def_ref_struct_lsp_keys():
    return (
        LSP_ENV.get_lsp_def().get_keys(),
        LSP_ENV.get_lsp_ref().get_keys(),
        LSP_ENV.get_lsp_structs().get_keys(),
    )


def parse_for_def_ref(text):
    PARSER.parse_expr(text)
    def_ = LSP_ENV.get_lsp_def()
    ref_ = LSP_ENV.get_lsp_ref()
    # struc_ = LSP_ENV.get_lsp_structs()
    print(def_)
    print(ref_)
    return def_, ref_


def check_ids(lsp_ids):
    lsp_ref = lsp_ids["lsp_ref"]
    lsp_def = lsp_ids["lsp_def"]
    lsp_structs = lsp_ids["lsp_structs"]
    # for x in lsp_ref.keys():
    #     print(x)


def parse_text(text):
    PARSER.parse_expr(text)
    lsp_ids = {
        "lsp_def": LSP_ENV.get_lsp_def().entries,
        "lsp_ref": LSP_ENV.get_lsp_ref().entries,
        "ids_might_be_structs_lsp_structs": LSP_ENV.get_ids_might_be_structs_lsp_structs().entries,
        "lsp_inside_structs": LSP_ENV.get_lsp_structs().entries,
        "lsp_structs_create": LSP_ENV.get_lsp_structs_create().entries,
    }
    return lsp_ids


def check_in_range(to_check, inside):
    print("==================")
    print("to_check:", to_check.lexpos)
    print("inside:", inside.lexpos)
    return (
        to_check.lexpos[0] <= inside.lexpos[0]
        and to_check.lexpos[1] >= inside.lexpos[1]
    )


def parse_text_structs(text):
    PARSER.parse_expr(text)
    lsp_ids = {
        # "lsp_def": LSP_ENV.get_lsp_def().entries,
        # "lsp_ref": LSP_ENV.get_lsp_ref().entries,
        "ids_might_be_structs_lsp_structs": LSP_ENV.get_ids_might_be_structs_lsp_structs().entries,
        "lsp_inside_structs": LSP_ENV.get_lsp_structs().entries,
        "lsp_structs_create": LSP_ENV.get_lsp_structs_create().entries,
    }
    i = 0
    id_name = "a"
    id = lsp_ids["ids_might_be_structs_lsp_structs"][id_name][i]
    lsp_structs_create = lsp_ids["lsp_structs_create"]["structs"]
    id_mapped_to_struct = {}
    for s in lsp_structs_create:
        if check_in_range(id, s):
            # if id_range[0] <= s_lexpos[0] and id_range[1] >= s_lexpos[1]:
            id_mapped_to_struct[id_name] = s.lexpos
    print("id_mapped_to_struct", id_mapped_to_struct)

    lsp_inside_structs = lsp_ids["lsp_inside_structs"]
    for key in lsp_ids["lsp_inside_structs"]:
        print(key, lsp_inside_structs[key])

    return lsp_ids


def calc_if_struct_var():
    i = 0
    id_name = "a"
    id = lsp_ids["ids_might_be_structs_lsp_structs"][id_name][i]
    lsp_structs_create = lsp_ids["lsp_structs_create"]["structs"]
    id_mapped_to_struct = {}
    for s in lsp_structs_create:
        if check_in_range(id, s):
            # if id_range[0] <= s_lexpos[0] and id_range[1] >= s_lexpos[1]:
            id_mapped_to_struct[id_name] = s.lexpos
    print("id_mapped_to_struct", id_mapped_to_struct)

    lsp_inside_structs = lsp_ids["lsp_inside_structs"]
    for key in lsp_ids["lsp_inside_structs"]:
        print(key, lsp_inside_structs[key])

    return lsp_ids


if __name__ == "__main__":
    text = r""" 
{
# x = 123;
# s = struct {
# 	.x = 7;
# 	.set_x = \A -> .x = A
# };
a = struct {
	.x = 7;
	.set_x = \A -> .x = A
}

}
"""
    entries = parse_text_structs(text)
    for entry in entries:
        print(entry, entries[entry])
    # check_ids(entries)
