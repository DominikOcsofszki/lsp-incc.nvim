# from incc_interpreter_ue08.LSP.LSP_ENV import get_lsp_def
from incc_interpreter_ue08.parser.parser import LSP_ENV
from lsprotocol import types

from incc_lsp.extracts_from_interpreter import PARSER_LSP


def find_column(input, lexpos):
    line_start = input.rfind("\n", 0, lexpos) + 1
    return lexpos - line_start


def publish_empty_diagnostic_msg(ls, document):
    ls.text_document_publish_diagnostics(
        types.PublishDiagnosticsParams(
            uri=document.uri,
            version=1,
            diagnostics=[],
        )
    )


def publish_all_diagnostics(ls, document, diagnostics):
    ls.text_document_publish_diagnostics(
        types.PublishDiagnosticsParams(
            uri=document.uri,
            version=1,
            diagnostics=diagnostics,
        )
    )


def create_diagnostic_msg(ls, document, line, character, msg):
    diagnostics = types.Diagnostic(
        message=msg,
        severity=types.DiagnosticSeverity.Error,
        range=types.Range(
            start=types.Position(line=line, character=character),
            end=types.Position(line=line, character=character),
        ),
    )
    return diagnostics


def EXTRACT_INFO(message):
    import re

    pattern = r"LexToken\((\w+),'(.*?)',(\d+),(\d+)\)"
    match = re.search(pattern, message)
    line_number, column_number = None, None
    if match:
        token_type = match.group(1)
        token_value = match.group(2)
        line_number = int(match.group(3))
        column_number = int(match.group(4))
        return line_number, column_number
    return line_number, column_number


def get_error_messages(error_msg: str):
    arr = error_msg.split("\n\r")
    return arr


def publish_all_error(ls, document, err):
    diagnostics: list[types.Diagnostic] = []
    error_msg = err.msg
    arr_err_msgs = get_error_messages(err.msg)

    for error_msg in arr_err_msgs:
        if error_msg:
            linenr, column = EXTRACT_INFO(error_msg)
            if linenr and column:
                diagnostics.append(
                    create_diagnostic_msg(ls, document, linenr, column, error_msg)
                )
    publish_all_diagnostics(ls, document, diagnostics)
    return


def reset_all_env_before_parsing():
    LSP_ENV.RESET_ALL_LSP_ENV()


def parse_and_check_for_errors(ls, document):
    reset_all_env_before_parsing()
    try:
        lsp_ids = PARSER_LSP.parse_text(document.source)
        publish_empty_diagnostic_msg(ls, document)
    except SyntaxError as err:
        publish_all_error(ls, document, err)
