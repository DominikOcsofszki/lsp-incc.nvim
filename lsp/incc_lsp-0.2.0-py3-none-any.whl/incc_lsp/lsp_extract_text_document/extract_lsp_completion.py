# from incc_interpreter_ue08.lexer.lexer import lexer, lsp_lexer
# from lsprotocol import types
#
# from incc_lsp.extracts_from_interpreter.interpreter_class_info import III
# from incc_lsp.lsp_extract_text_document.TokenInfoClasses import InccLexTokenInfo
#
# # III = InccInterpreterImported()
#
#
# def getTokenFromDataDepth(data: str) -> list[InccLexTokenInfo]:
#     lexer.input(data)
#     all_ids: list[InccLexTokenInfo] = []
#
#     while True:
#         tok = lexer.token()
#         if tok:
#             if tok.type == "IDENT":
#                 info = InccLexTokenInfo(
#                     tok.value, tok.lineno, tok.lexpos, tok.lexer, tok.type
#                 )
#                 # info = LexTokenInfo(tok.value, tok.lexpos, depth)
#                 all_ids.append(info)
#
#         if not tok:
#             break
#     return all_ids
#
#
# # def add_helper_reserved_word():
# #     return ["h." + str.lower(x) for x in III.LEXER_reserved_words]
#
#
# # def get_helper_CompletionItem() -> list[types.CompletionItem]:
# #     auto_completion = add_helper_reserved_word()
# #     return [
# #         types.CompletionItem(label=x, kind=18, detail="TEST") for x in auto_completion
# #     ]
#
#
# # def get_CompletionItem_LEXER_reserved_words():
# #     auto_completion = [str.lower(x) for x in III.LEXER_reserved_words]
# #     return [types.CompletionItem(label=x, kind=14) for x in auto_completion]
#
#
# def get_IDs_from_data(data: str):
#     arr = getTokenFromDataDepth(data)
#     arr = [x.value for x in arr]
#     arr = list(set(arr))
#     return [types.CompletionItem(label=x, kind=18) for x in arr]
#
#
# def get_struct_context(data: str):
#     arr = getTokenFromDataDepth(data)
#     arr = [x.value for x in arr]
#     arr = list(set(arr))
#     return [types.CompletionItem(label=x, kind=18) for x in arr]
