from dataclasses import dataclass

from ply.lex import Lexer, LexToken


@dataclass
class InccSemanticToken:
    line_offset: int
    pos_offset: int
    text: str
    tok_type: str


@dataclass
class InccLexTokenInfo(LexToken):
    value: str
    lineno: int
    lexpos: int
    lexer: Lexer
    type: str
