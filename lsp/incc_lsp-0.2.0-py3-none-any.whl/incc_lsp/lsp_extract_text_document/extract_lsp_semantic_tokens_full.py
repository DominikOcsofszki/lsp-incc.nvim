# import re

from incc_interpreter_ue08.lexer.lexer import lexer, lsp_lexer

from incc_lsp.lsp_extract_text_document.TokenInfoClasses import (
    InccLexTokenInfo,
    InccSemanticToken,
)


def get_sem_tok_new(
    tok: InccLexTokenInfo, prev_line: int, prev_pos: int
) -> tuple[InccSemanticToken, int, int]:
    line_offset = tok.lineno - prev_line
    if line_offset > 0:
        if hasattr(tok, "lexer"):
            pos_offset = tok.lexpos - tok.lexer.line_start_pos
        else:
            pos_offset = 0
            if tok.__dict__.get("line_start_pos"):
                pos_offset = tok.lexpos - tok.line_start_pos
    else:
        pos_offset = tok.lexpos - prev_pos
    text = tok.value
    tok_type = tok.type
    _sem_tok = InccSemanticToken(
        line_offset=line_offset,
        pos_offset=pos_offset,
        text=text,
        tok_type=tok_type,
    )
    _prev_line, _prev_pos = tok.lineno, tok.lexpos
    return _sem_tok, _prev_line, _prev_pos


def getTokensLexerSemanticTokens(data: str) -> list[InccSemanticToken]:
    lexer = lsp_lexer
    lexer.input(data)
    lexer.lineno = 1
    all_tok: list[InccSemanticToken] = []
    prev_line: int = 1
    prev_pos: int = 0

    while True:
        tok: InccLexTokenInfo | None = lexer.token()
        if tok:
            _sem_tok, _prev_line, _prev_pos = get_sem_tok_new(tok, prev_line, prev_pos)
            sem_tok, prev_line, prev_pos = _sem_tok, _prev_line, _prev_pos
            all_tok.append(sem_tok)
        if not tok:
            break
    return all_tok


def parseHighlightTokens(text) -> list[InccSemanticToken]:
    tokens = getTokensLexerSemanticTokens(text)
    return tokens


if __name__ == "__main__":
    data = """{b =123; ca = 1 + c;
               x+a; x= s.x}
    """
    res = parseHighlightTokens(data)
    print(res)
